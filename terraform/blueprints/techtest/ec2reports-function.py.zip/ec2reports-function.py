def lambda_handler(event, context):
   import boto3
   import time
   import datetime

   client = boto3.client('ec2')
   now = datetime.datetime.now()
   dynamodb = boto3.resource('dynamodb')

   # Set a TTL of now + 1 day (86400s)
   epoch = round(time.time())
   ttl = epoch + 86400

   # Get ec2 instance status
   response = client.describe_instance_status(
     IncludeAllInstances=True
   )

   # construct the data to be added to dynamodb
   message=[]
   for instances in response['InstanceStatuses']:
      status = instances['InstanceState']['Name']
      id = instances['InstanceId']
      entry=id, status
      message.append(entry)

   #print("Status of instances is: %s" % (message,))


   # Get DynamoDB table and put the data
   table = dynamodb.Table('ec2reports')

   table.put_item(
      Item={
         'ttl':ttl,
         'date':(now.strftime("%Y-%m-%d %H:%M:%S")),
         'message':("Status of instances is: %s" % (message,))
      }
   )

